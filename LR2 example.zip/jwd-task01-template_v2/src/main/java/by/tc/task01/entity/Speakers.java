package by.tc.task01.entity;

public class Speakers extends Appliance{
	// you may add your own code here
}

package by.tc.task01.entity;

public class Refrigerator extends Appliance{
	// you may add your own code here
}

package by.tc.task01.entity;

public class Oven extends Appliance{
	// you may add your own code here
}
